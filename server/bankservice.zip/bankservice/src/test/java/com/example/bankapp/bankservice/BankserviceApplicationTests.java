package com.example.bankapp.bankservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BankserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
